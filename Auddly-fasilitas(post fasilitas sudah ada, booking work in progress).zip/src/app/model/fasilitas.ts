export interface Fasilitas{
  count:number,
  fasilitas:[]
};

export interface FasilitasDetail{
  result: {
    fasilitas: []
  }
}