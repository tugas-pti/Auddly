import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { FasilitasService } from '../services/fasilitas.service';
import { FasilitasDetail } from '../model/fasilitas';

@Component({
  selector: 'app-tampil-fasilitas-detail',
  templateUrl: './tampil-fasilitas-detail.component.html',
  styleUrls: ['./tampil-fasilitas-detail.component.scss']
})
export class TampilFasilitasDetailComponent implements OnInit {

  public _fasilitas: FasilitasDetail;
  public kodeFasilitas: any;
  constructor(
    public fasilitasApi: FasilitasService,
    public activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {

    let kode = this.activatedRoute.snapshot.paramMap.get('kode');

    this.fasilitasApi.getFasilitasByKode(kode).subscribe(
    data => { this._fasilitas = data; console.log(data);},
    error => { console.log(error); }
    );
    
  }

}
