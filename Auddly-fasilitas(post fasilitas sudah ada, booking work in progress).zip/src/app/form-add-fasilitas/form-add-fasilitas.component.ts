import { Component} from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
//import { SubmitService } from '../services/submit.service'
import { FasilitasService } from '../services/fasilitas.service';

@Component({
  selector: 'app-form-add-fasilitas',
  templateUrl: './form-add-fasilitas.component.html',
  styleUrls: ['./form-add-fasilitas.component.scss']
})
export class FormAddFasilitasComponent {

  get userName(){
    return this.registrationForm.get('userName');
  }

  constructor(private fb: FormBuilder, private submitService: FasilitasService) { }

  registrationForm = this.fb.group({
    kode: [''],
    nama: [''],
    fakultas: [''],
    gambar: [''],
    deskripsi: [''],
    jamBuka: [''],
    jamTutup: ['']/*,
    token: ['']*/

  });

  loadAPIData(){
    this.registrationForm.patchValue({
      userName: 'Farik',
      kode: 'kode',
      nama: 'nama',
      fakultas: 'fakultas',
      gambar: 'gambar',
      deskripsi: 'deskripsi',
      jamBuka: '01:30',
      jamTutup: '03:30'/*,
      token: 'eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoiMSIsInRlbGVwb24iOiIwODg5MjM2NjQ2NiIsImVtYWlsIjoiYmlmZWxkeUBnbWFpbC5jb20iLCJuYW1hX2xlbmdrYXAiOiJCYXNpbGl1cyBCaWFzIEFzdGhvIENocmlzdHlvbm8iLCJhbGFtYXQiOiJTbGVtYW4sIFlvZ3lha2FydGEiLCJ0YW5nZ2FsX2xhaGlyIjoiMTk5OC0wNi0xNCIsImZvdG8iOiJodHRwczovL2kucHhpbWcubmV0L2ltZy1vcmlnaW5hbC9pbWcvMjAxOS8xMS8wNy8wMy81Ni8wNi83NzY5MDk4Ml9wMC5wbmciLCJjcmVhdGVkX2F0IjoiMTU3Mzc1MTUwNzAwMCIsInVwZGF0ZWRfYXQiOiIxNTczNzY0OTU0ODU3In0sImlhdCI6MTU3NDIzMDk3NywiZXhwIjoxNTc0MjMxMTU3LCJhdWQiOiJNYWhhc2lzd2FQVEktMjAxOSIsImlzcyI6IkJpYXNZZWhlei0yMDE2In0.8CLOkc3nNWCMmsKkzGyWAd-PWTd3I_IwVCb5ZotYIVoUsNVEAalM-5rynTzqdz_JEkBVYYBHw5WXfatb15Nj9Q'*/
    });
  }

  onSubmit(){
    console.log(this.registrationForm.value);
    this.submitService.postFasilitas(this.registrationForm.value)
    .subscribe(
      response => console.log('Success! ', response),
      error => console.log('Error', error)
    )
  }

}
