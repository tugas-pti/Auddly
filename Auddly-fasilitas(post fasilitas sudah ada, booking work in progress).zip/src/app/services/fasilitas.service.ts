import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';

import { Fasilitas, FasilitasDetail } from '../model/fasilitas'

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'x-access-token': "eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoiMSIsIm5pbSI6IjAwMDAwMDEzNTM2IiwiZm90byI6Imh0dHBzOi8vaS5weGltZy5uZXQvaW1nLW9yaWdpbmFsL2ltZy8yMDE5LzExLzA3LzAzLzU2LzA2Lzc3NjkwOTgyX3AwLnBuZyIsImVtYWlsIjoiYmlmZWxkeUBnbWFpbC5jb20iLCJuYW1hX2xlbmdrYXAiOiJCYXNpbGl1cyBCaWFzIEFzdGhvIENocmlzdHlvbm8iLCJ0ZWxlcG9uIjoiMDg4OTIzNjY0NjYiLCJ0YW5nZ2FsX2xhaGlyIjoiMTk5OC0wNi0xNCAxMjozNCIsImFsYW1hdCI6IlNsZW1hbiwgWW9neWFrYXJ0YSIsInJvbGUiOiJBc2lzdGVuIExhYi4gUHJha3Rpa3VtIiwiY3JlYXRlZF9hdCI6IjE1NzM3NTE1MDcwMDAiLCJ1cGRhdGVkX2F0IjoiMTU3Mzc2NDk1NDg1NyJ9LCJpYXQiOjE1NzM3ODI1MzUsImV4cCI6MTU3Mzc4NjEzNSwiYXVkIjoiTWFoYXNpc3dhUFRJLTIwMTkiLCJpc3MiOiJCaWFzWWVoZXotMjAxNiJ9.TNhnIhViRaEWWPC41cX_uzCI9XCWVY7bTMlBWWQrduq6fgfb0bok5NVsqyM9056v2lIaI7f_R8Qztceae8a8IQ",
    'Authorization': 'Bearer eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7ImlkIjoiMSIsInRlbGVwb24iOiIwODg5MjM2NjQ2NiIsImVtYWlsIjoiYmlmZWxkeUBnbWFpbC5jb20iLCJuYW1hX2xlbmdrYXAiOiJCYXNpbGl1cyBCaWFzIEFzdGhvIENocmlzdHlvbm8iLCJhbGFtYXQiOiJTbGVtYW4sIFlvZ3lha2FydGEiLCJ0YW5nZ2FsX2xhaGlyIjoiMTk5OC0wNi0xNCIsImZvdG8iOiJodHRwczovL2kucHhpbWcubmV0L2ltZy1vcmlnaW5hbC9pbWcvMjAxOS8xMS8wNy8wMy81Ni8wNi83NzY5MDk4Ml9wMC5wbmciLCJjcmVhdGVkX2F0IjoiMTU3Mzc1MTUwNzAwMCIsInVwZGF0ZWRfYXQiOiIxNTczNzY0OTU0ODU3In0sImlhdCI6MTU3NDI0Mzc3MywiZXhwIjoxNTc0MjQzOTUzLCJhdWQiOiJNYWhhc2lzd2FQVEktMjAxOSIsImlzcyI6IkJpYXNZZWhlei0yMDE2In0.BPDq-SVLbJIVYxWhNX-n-q7RygOgNdp3vhqD_5CX4K0g3ev6yvPfA3I8nMzKCsORvSBvfGUO1p7Z15M_3_zRwA'
  })
};


@Injectable({
  providedIn: 'root'
})

export class FasilitasService {

  private urlApi = 'https://umn-pti2019.herokuapp.com';

  constructor(
    private http: HttpClient
  ) { }

  getAllFasilitas(): Observable<Fasilitas>{
    return this.http.get<Fasilitas>(`${this.urlApi}/api/fasilitas`);
  }

  getFasilitasByKode(kode:string): Observable<FasilitasDetail>{
    return this.http.get<FasilitasDetail>(`${this.urlApi}/api/fasilitas/${kode}`);
  }

  postFasilitas (fasilitas: Fasilitas): Observable<Fasilitas> {
    return this.http.post<Fasilitas>(`${this.urlApi}/api/fasilitas`, fasilitas, httpOptions);
  }
}
