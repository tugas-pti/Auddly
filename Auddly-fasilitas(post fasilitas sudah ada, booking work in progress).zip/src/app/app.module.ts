import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { TampilFasilitasComponent } from './tampil-fasilitas/tampil-fasilitas.component';
import { TampilFasilitasDetailComponent } from './tampil-fasilitas-detail/tampil-fasilitas-detail.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FormAddFasilitasComponent } from './form-add-fasilitas/form-add-fasilitas.component';
import { NgbdModalBasic } from './modal/modal-basic';
import { BookingComponent } from './booking/booking.component';



@NgModule({
  declarations: [
    AppComponent,
    TampilFasilitasComponent,
    TampilFasilitasDetailComponent,
    HomeComponent,
    HeaderComponent,
    FormAddFasilitasComponent,
    NgbdModalBasic,
    BookingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
