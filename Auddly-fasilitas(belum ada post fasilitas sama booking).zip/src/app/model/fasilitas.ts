export interface Fasilitas{
    info:string,
    result: {
      count:number,
      fasilitas:[]
    };
}

export interface FasilitasDetail{
  info:string,
  result: {};
}