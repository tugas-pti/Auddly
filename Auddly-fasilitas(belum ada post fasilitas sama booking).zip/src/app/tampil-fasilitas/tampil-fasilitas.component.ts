import { Component, OnInit } from '@angular/core';
import { Fasilitas } from '../model/fasilitas';
import { FasilitasService } from '../services/fasilitas.service';

@Component({
  selector: 'app-tampil-fasilitas',
  templateUrl: './tampil-fasilitas.component.html',
  styleUrls: ['./tampil-fasilitas.component.scss']
})
export class TampilFasilitasComponent implements OnInit {

  public fasilitas: Fasilitas = null;

  constructor(
    private fasilitasApi: FasilitasService
  ) { }

  ngOnInit() {
    this.fasilitasApi.getAllFasilitas().subscribe(
      data => { this.fasilitas = data; /*console.log(data)*/}, 
      error => { console.log(error); }
    );
  }

  addFasilitas(newFasilitas: Fasilitas){
    this.fasilitasApi
  .postFasilitas(newFasilitas);
  }

}
