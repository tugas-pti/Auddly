import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-add-fasilitas',
  templateUrl: './form-add-fasilitas.component.html',
  styleUrls: ['./form-add-fasilitas.component.scss']
})
export class FormAddFasilitasComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
