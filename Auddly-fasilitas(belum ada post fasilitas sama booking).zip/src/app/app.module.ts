import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';

import { TampilFasilitasComponent } from './tampil-fasilitas/tampil-fasilitas.component';
import { TampilFasilitasDetailComponent } from './tampil-fasilitas-detail/tampil-fasilitas-detail.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { FormAddFasilitasComponent } from './form-add-fasilitas/form-add-fasilitas.component';


@NgModule({
  declarations: [
    AppComponent,
    TampilFasilitasComponent,
    TampilFasilitasDetailComponent,
    HomeComponent,
    HeaderComponent,
    FormAddFasilitasComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
