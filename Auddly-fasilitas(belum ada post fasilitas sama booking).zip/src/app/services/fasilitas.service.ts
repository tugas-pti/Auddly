import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';

import { Fasilitas, FasilitasDetail } from '../model/fasilitas'

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'x-access-token': '',
    'Authorization': 'my-auth-token'
  })
};


@Injectable({
  providedIn: 'root'
})

export class FasilitasService {

  private urlApi = 'https://umn-pti2019.herokuapp.com';

  constructor(
    private http: HttpClient
  ) { }

  getAllFasilitas(): Observable<Fasilitas>{
    return this.http.get<Fasilitas>(`${this.urlApi}/api/fasilitas`);
  }

  getFasilitasByKode(kode:string): Observable<FasilitasDetail>{
    return this.http.get<FasilitasDetail>(`${this.urlApi}/api/fasilitas/${kode}`);
  }

  postFasilitas (fasilitas: Fasilitas): Observable<Fasilitas> {
    return this.http.post<Fasilitas>(this.urlApi, fasilitas, httpOptions);
  }
}
