export interface Mahasiswa{
    info: string;
    result: {
        count: number,
        mahasiswa: []
    };
}