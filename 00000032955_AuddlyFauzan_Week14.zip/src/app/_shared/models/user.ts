export class User{
    constructor(
        public nim: string,
        public nama: string,
        public alamat: string,
    ){}
}