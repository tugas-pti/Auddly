import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { PelayanApiService } from '../_shared/services/pelayan-api.service';
import { Mahasiswa } from '../_shared/models/mahasiswa';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {
  public user: Mahasiswa = null;
  constructor(
    private pelayananApi: PelayanApiService,
    public activatedRoute: ActivatedRoute
  ) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.user = this.pelayananApi.getMahasiswaById(params.nim);
    });
  }

}
