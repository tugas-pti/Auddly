import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute } from '@angular/router';

import { booking, FasilitasDetail } from '../model/fasilitas';
import { FasilitasService } from '../services/fasilitas.service';
import { first } from 'rxjs/operators';

@Component({
  selector: 'ngbd-modal-basic',
  templateUrl: './modal-basic.html'
})
export class NgbdModalBasic implements OnInit{
  @Input() fasilitasInfo: any;

  closeResult: string;

  arrBooking: any[]=[];

  public _kode: string;
  public _nama: string;

  bookingForm = this.fb.group({
    tanggal: ['', Validators.required],
    jamPakai: ['', Validators.required],
    jamSelesai: ['', Validators.required]
  });

  constructor(private modalService: NgbModal, 
              private fb: FormBuilder, 
              private activatedRoute: ActivatedRoute) {
  }
  ngOnInit(){
    this._kode = this.activatedRoute.snapshot.paramMap.get('kode');
    this._nama = this.activatedRoute.snapshot.paramMap.get('nama');
  }

  open(content: any) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    });
  }
  // private getDismissReason(reason: any): string {
  //   if (reason === ModalDismissReasons.ESC) {
  //     return 'by pressing ESC';
  //   } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
  //     return 'by clicking on a backdrop';
  //   } else {
  //     return  `with: ${reason}`;
  //   }
  // }
  onSubmit(){
    // Agar localStorage tidak kosong setiap kali di refresh
    var tempArray = {
      nama: this.fasilitasInfo.nama,
      kode: this.fasilitasInfo.kode,
      bookingDetails: this.bookingForm.value
    }
    this.arrBooking = localStorage.getItem('booking') ? JSON.parse(localStorage.getItem('booking')) : [];
    this.arrBooking.push(tempArray);
    // masukkan ke localstorage
    localStorage.setItem('booking', JSON.stringify(this.arrBooking))
    // console.log(JSON.parse(localStorage.getItem('booking')));
    // console.log(this.arrBooking);
    // localStorage.clear
    console.log(tempArray);
  }
}
