import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TampilFasilitasDetailComponent } from './tampil-fasilitas-detail.component';

describe('TampilFasilitasDetailComponent', () => {
  let component: TampilFasilitasDetailComponent;
  let fixture: ComponentFixture<TampilFasilitasDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TampilFasilitasDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TampilFasilitasDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
