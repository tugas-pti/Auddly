import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json'
  })
};


@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http: HttpClient) { }

  private urlApi = 'https://umn-pti2019.herokuapp.com';
  //private urlApi = 'http://bifeldy.ip-dynamic.net:80';

  // getList() {
  //   return this.http.get('https://api.openbrewerydb.org/breweries');
  // };

  registerForm(data: any): Observable<any> {
    return this.http.post<any>(`${this.urlApi}/api/register`, data, httpOptions);
  }
}
