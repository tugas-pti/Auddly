import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { booking } from '../model/fasilitas';

@Injectable({
    providedIn: 'root'
})
export class BookingService {
  public bookedFasilitas: booking;
  private messageSource = new BehaviorSubject<booking>(new booking);
  currentMessage = this.messageSource.asObservable();

  constructor() { }

  updateBooking(data: booking){
    this.messageSource.next(data)
  };

}