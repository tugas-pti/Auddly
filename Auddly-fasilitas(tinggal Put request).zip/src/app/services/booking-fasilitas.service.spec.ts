import { TestBed } from '@angular/core/testing';

import { BookingFasilitasService } from './booking-fasilitas.service';

describe('BookingFasilitasService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BookingFasilitasService = TestBed.get(BookingFasilitasService);
    expect(service).toBeTruthy();
  });
});
