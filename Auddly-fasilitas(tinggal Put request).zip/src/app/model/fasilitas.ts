export interface Fasilitas{
  info: string;
  result: {
    count: number;
    fasilitas: [];
  }
};

export interface FasilitasDetail{
  info: string;
  result: {
    fasilitas: [];
  }

}

export class booking{
  kode: string;
  nama: string;
  tanggal: string;
  jamPakai: string;
  jamSeelsai: string;
}