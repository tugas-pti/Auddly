import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TampilFasilitasComponent } from './tampil-fasilitas.component';

describe('TampilFasilitasComponent', () => {
  let component: TampilFasilitasComponent;
  let fixture: ComponentFixture<TampilFasilitasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TampilFasilitasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TampilFasilitasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
