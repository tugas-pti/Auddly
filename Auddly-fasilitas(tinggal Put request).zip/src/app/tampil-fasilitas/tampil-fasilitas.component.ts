import { Component, OnInit } from '@angular/core';
import { Fasilitas, FasilitasDetail } from '../model/fasilitas';
import { FasilitasService } from '../services/fasilitas.service';

@Component({
  selector: 'app-tampil-fasilitas',
  templateUrl: './tampil-fasilitas.component.html',
  styleUrls: ['./tampil-fasilitas.component.scss']
})
export class TampilFasilitasComponent implements OnInit {

  public fasilitas: Fasilitas = null;

  public bookingFasilitasDetail: FasilitasDetail;
  constructor(
    private fasilitasApi: FasilitasService
  ) { }

  ngOnInit() {
    this.fasilitasApi.getAllFasilitas().subscribe(
      data => { this.fasilitas = data; }, 
      error => { console.log(error); }
    );
  }

  showFasilitas(){
    console.log(this.fasilitas.result);
  }

  addFasilitas(newFasilitas: Fasilitas){
    this.fasilitasApi
  .postFasilitas(newFasilitas);
  }

}
