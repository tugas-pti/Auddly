import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TampilFasilitasComponent } from './tampil-fasilitas/tampil-fasilitas.component';
import { TampilFasilitasDetailComponent } from './tampil-fasilitas-detail/tampil-fasilitas-detail.component';
import { HomeComponent } from './home/home.component';
import { FormAddFasilitasComponent } from './form-add-fasilitas/form-add-fasilitas.component';
import { FormComponent } from './form/form.component';
import { BookingComponent } from './booking/booking.component';


const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch:'full' },
  { path: 'home', component: HomeComponent },
  { path: 'fasilitas', component: TampilFasilitasComponent },
  { path: 'fasilitas/:kode', component: TampilFasilitasDetailComponent },
  { path: 'addFasilitas', component: FormAddFasilitasComponent },
  { path: 'register', component: FormComponent },
  { path: 'booking', component: BookingComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
