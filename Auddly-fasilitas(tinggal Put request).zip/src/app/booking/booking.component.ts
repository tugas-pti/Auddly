import { Component, OnInit, Input } from '@angular/core';
import { booking } from '../model/fasilitas';
import { FasilitasService } from '../services/fasilitas.service'
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss']
})
export class BookingComponent implements OnInit {

  public bookedDetails: booking[]=[];
  get isEmpty(){
    if(this.bookedDetails.length == 0){
      return true;
    }
    else{
      return false;
    }
  }
  constructor(private fs: FasilitasService, private activatedRoute: ActivatedRoute){ }

  ngOnInit() {
    let kode = this.activatedRoute.snapshot.paramMap.get('kode')
    this.bookedDetails = JSON.parse(localStorage.getItem('booking'));
    this.fs.getFasilitasByKode(kode).subscribe()
  }

  deleteBooking(index: number){
    this.bookedDetails.splice(index, 1);
    localStorage.setItem('booking',JSON.stringify(this.bookedDetails))
  }

  

}
