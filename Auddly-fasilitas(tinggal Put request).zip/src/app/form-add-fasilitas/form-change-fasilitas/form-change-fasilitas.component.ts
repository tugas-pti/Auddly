import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms'
@Component({
  selector: 'app-form-change-fasilitas',
  templateUrl: './form-change-fasilitas.component.html',
  styleUrls: ['./form-change-fasilitas.component.scss']
})
export class FormChangeFasilitasComponent implements OnInit {

  constructor(private fg: FormBuilder) { }

  changeFasilitasForm = this.fg.group({
    
  })
  ngOnInit() {
  }

}
