import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormChangeFasilitasComponent } from './form-change-fasilitas.component';

describe('FormChangeFasilitasComponent', () => {
  let component: FormChangeFasilitasComponent;
  let fixture: ComponentFixture<FormChangeFasilitasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormChangeFasilitasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormChangeFasilitasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
