import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormAddFasilitasComponent } from './form-add-fasilitas.component';

describe('FormAddFasilitasComponent', () => {
  let component: FormAddFasilitasComponent;
  let fixture: ComponentFixture<FormAddFasilitasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormAddFasilitasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormAddFasilitasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
