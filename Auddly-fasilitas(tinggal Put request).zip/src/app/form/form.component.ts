import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms'
import * as CryptoJS from 'crypto-js';

import { HttpService } from '../services/http.service'
import { first } from 'rxjs/operators';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {


  registrationForm = this.fb.group({
    user_name: [''],
    telepon: [''],
    email: [''],
    nama_lengkap: [''],
    alamat: [''],
    tanggal_lahir: [''],
    foto:[''],
    password: []
  })

  constructor(private fb: FormBuilder, private _http: HttpService) { }

  ngOnInit() {
  }

  loadAPI(){
    this.registrationForm.patchValue({
      user_name: 'orangeTroll',
      telepon: '0879256636',
      email: 'fuck@email.com',
      nama_lengkap: 'Donald Trump',
      alamat: 'Tangerang, Selatan',
      tanggal_lahir: '2001-05-01',
      foto:'https://i.pximg.net/img-original/img/2019/11/07/03/56/06/77690982_p0.png\",\r\n\t\"password\": \"12b03226a6d8be9c6e8cd5e55dc6c7920caaa39df14aab92d5e3ea9340d1c8a4d3d0b8e4314f1f6ef131ba4bf1ceb9186ab87c801af0d5c95b1befb8cedae2b9',
      password: 'f4k3n3wz'
    })
  };

  onSubmit(){

    this.registrationForm.controls.password.patchValue(
      CryptoJS.SHA512(this.registrationForm.value.password).toString()
    );
    console.log(this.registrationForm.value);
    this._http.registerForm(this.registrationForm.value).pipe(first())
    .subscribe(
      response => {console.log(response)},
      error => {console.log('Error', error)}
    )
  };

}
